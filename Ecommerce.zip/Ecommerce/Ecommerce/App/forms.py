from django import forms
from .models import *

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price', 'image']


class ContactForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField()
    message = forms.CharField(widget=forms.Textarea)

class CartItem(forms.ModelForm):
    class Meta:
        model = CartItem
        fields = ['user','product','quantity']

class OrderForm(forms.ModelForm):
    class Meta:
        model = Orders
        fields = ['receiver_name', 'mobile_number', 'address', 'payment_method']
        widgets = {
            'mobile_number': forms.TextInput(attrs={'pattern': '[0-9]{10}'}),
        }
        
class BannerForm(forms.ModelForm):
    class Meta:
        model = Banner
        fields = ['bannername','bannerimage']

class ContactForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField()
    mobile = forms.CharField(max_length=10)
    subject = forms.CharField(max_length=100)
    message = forms.CharField(widget=forms.Textarea)