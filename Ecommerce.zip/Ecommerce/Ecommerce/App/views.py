from pyexpat.errors import messages
from django.db.models.fields import BLANK_CHOICE_DASH
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse_lazy
from App.forms import ProductForm
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.conf import settings
from django.shortcuts import render, HttpResponse
import json
from .models import *
from .forms import *
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from django.db import transaction


def signup(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')
        
        # Check if the user already exists
        if User.objects.filter(username=uname).exists():
            return HttpResponse("Username already exists!")

        if pass1 != pass2:
            return HttpResponse("Your passwords do not match.")
        else:
            my_user = User.objects.create_user(uname, email, pass1)
            my_user.save()
            return redirect('login')
    return render(request, 'signup.html')

def loginpage(request):
    if request.method=='POST':
        userss = request.POST.get('userss')
        passs = request.POST.get('passs')
        user = authenticate(request, username=userss, password=passs)
        if user is not None:
            login(request, user)
            if request.user.is_superuser:
                return redirect('user_order_admin_view')
            else:
                return redirect ('home')
        else:
            return HttpResponse("user or password incorrect!")
    return render(request, 'login.html')

@login_required
def home(request):
    banner=Banner.objects.all()
    prod=Product.objects.all()
    return render(request, 'home.html',{'prod':prod, 'banner': banner})

def logoutbutton(request):
    logout(request)
    return redirect('login')

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('add_product')
    else:
         form = ProductForm()
    return render(request,'add_product.html', {'form': form})

def product_list(request):
    prod=Product.objects.all()

    return render(request, 'product_list.html',{'prod':prod})

def your_cart(request):
    prod = CartItem.objects.filter(user=request.user)
    total_pricepp = sum(item.total_price() for item in prod)

    # Pass the cart items and total price to the template
    context = {
        'cart_items': prod,
        'total_pricepp': total_pricepp,
    }
    return render(request, 'your_cart.html',{'prod':prod})

from django.shortcuts import get_object_or_404

def add_to_cart(request):
    if request.method == 'POST':
        cart_quantity = int(request.POST.get("quantity", 1))
        cart_product_id = int(request.POST.get("product", 0))

        try:
            product = Product.objects.get(pk=cart_product_id)
            cart_items = CartItem.objects.filter(user=request.user, product=product)

            if cart_items.exists():
                # If the item is already in the cart, update the quantity and total price
                cart_item = cart_items.first()  # Assuming you want to update the first item
                cart_item.quantity += cart_quantity
            else:
                # If the item is not in the cart, create a new cart item
                cart_item = CartItem.objects.create(
                    user=request.user,
                    product=product,
                    quantity=cart_quantity,
                )

            cart_item.save()

            return redirect('home')
        except Product.DoesNotExist:
            return HttpResponse("Product not found", status=404)
    else:
        return HttpResponse(status=400)  # Bad Request
    

    
from django.shortcuts import render, redirect
from .forms import ContactForm
from .models import ContactMessage

def contact_us(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Save form data to the database
            contact_message = ContactMessage(
                name=form.cleaned_data['name'],
                email=form.cleaned_data['email'],
                mobile = form.cleaned_data['mobile'],
                subject=form.cleaned_data['subject'],
                message=form.cleaned_data['message']
            )
            contact_message.save()
            return render(request, 'message_received.html')  # Redirect to a success page
    else:
        form = ContactForm()
    return render(request, 'contact_us.html', {'form': form})

def messages_to_admin(request):
    messages = ContactMessage.objects.all()
    return render(request, 'messages_to_admin.html', {'messages': messages})

from django.shortcuts import redirect, get_object_or_404
from .models import CartItem

def decrease_quantity(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        cart_item = get_object_or_404(CartItem, id=item_id)
        
        # Decrease the quantity or delete if it's 1
        if cart_item.quantity > 1:
            cart_item.quantity -= 1
            cart_item.save()
        else:
            cart_item.delete()

    return redirect('your_cart')  # Redirect back to your cart page

def increase_quantity(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        cart_item = get_object_or_404(CartItem, id=item_id)
        
        # Decrease the quantity or delete if it's 1
        # if cart_item.quantity < 1:
        cart_item.quantity += 1
        cart_item.save()

    return redirect('your_cart')

def delete_item(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        try:
            item = CartItem.objects.get(id=item_id)
            item.delete()
            return redirect('your_cart')
        except CartItem.DoesNotExist:
            return redirect('your_cart')
    else:
        return redirect('your_cart')

def delete_item_admin(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        try:
            item = Product.objects.get(id=item_id)
            item.delete()
            return redirect('product_list')
        except CartItem.DoesNotExist:
            return redirect('product_list')
    else:
        return redirect('product_list')
    
    

def user_orders(request):
    try:
        # Fetch orders for the authenticated user
        user_orders = Orders.objects.filter(user=request.user)
        
        # Create an empty list to store order details
        orders_details = []
        
        # Iterate through each order
        for order in user_orders:
            # Fetch all order items associated with this order
            order_items = OrderItem.objects.filter(order=order)
            # Append order and its associated order items to orders_details list
            orders_details.append({'order': order, 'order_items': order_items})
        
        # Render the user orders template with orders_details
        return render(request, 'user_orders.html', {'orders_details': orders_details})
    
    except Exception as e:
        return HttpResponse(f"An error occurred: {e}")


def popup(request):
    if request.method == 'POST':
        try:
            receiver_name = request.POST.get('receiver_name')
            mobile_number = request.POST.get('mobile_number')
            address = request.POST.get('address')
            payment_method = request.POST.get('payment_method')
            
            # Retrieve cart items for the current user
            cart_items = CartItem.objects.filter(user=request.user)
            
            # Calculate total amount
            total_amount = sum(item.total_price() for item in cart_items)
            
            # Create the order instance with the authenticated user
            with transaction.atomic():
                order = Orders.objects.create(user=request.user, receiver_name=receiver_name, 
                                              mobile_number=mobile_number, address=address, 
                                              payment_method=payment_method, total_amount=total_amount)
                
                # Associate cart items with the order and update quantities
                for cart_item in cart_items:
                  
                    order_item = OrderItem.objects.create(order=order, product=cart_item.product,
                                                           quantity=cart_item.quantity, price=cart_item.total_price())
                
                # Clear the user's cart after placing the order
                cart_items.delete()
            
            # Redirect to a success page or any other page
            return redirect('your_cart')  # Replace 'your_cart' with the URL name of your cart page
        
        except Exception as e:
            print(f"Error occurred while saving order: {e}")
            # Handle the error appropriately, maybe redirect to an error page or render the form again with an error message.
            return HttpResponse("An error occurred while processing your request.")
    else:
        # Render the form template if it's a GET request
        return render(request, 'popup.html')


def banner(request):
    
    if request.method == 'POST':
        form = BannerForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('banner')
    else:
         form = BannerForm()
    prod=Banner.objects.all()
    return render(request,'banner.html', {'form': form, 'prod':prod})

def delete_banner(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        if item_id:
            try:
                item = Banner.objects.get(pk=item_id)
                item.delete()
                # Optionally, you can add a success message or perform other actions
            except Banner.DoesNotExist:
                # Handle the case where the item doesn't exist
                pass
    return redirect('banner')

def footer(request):
    return render(request, 'footer.html')

def user_order_admin_view(request):
    try:
        # Fetch orders for the authenticated user
        user_orders = Orders.objects.all()
        
        # Create an empty list to store order details
        orders_details = []
        
        # Iterate through each order
        for order in user_orders:
            # Fetch all order items associated with this order
            order_items = OrderItem.objects.filter(order=order)
            # Append order and its associated order items to orders_details list
            orders_details.append({'order': order, 'order_items': order_items})
        
        # Render the user orders template with orders_details
        return render(request, 'user_order_admin_view.html', {'orders_details': orders_details})
    
    except Exception as e:
        return HttpResponse(f"An error occurred: {e}")
    
def confirm_order(request, order_id):
    if request.method == 'POST':
        order = Orders.objects.get(pk=order_id)
        order.status = 'Your Order Confirmed'
        order.save()
        return redirect('user_order_admin_view')  # Assuming 'user_orders' is the URL name for the page displaying user orders
    else:
        return redirect('user_order_admin_view')

from django.contrib.auth.views import PasswordResetView, PasswordResetConfirmView
from django.contrib.auth.forms import PasswordResetForm


def forgot_password(request):
    if request.method == 'POST':
        form =  PasswordResetForm(request.POST)
        if form.is_valid():
            try:
                form.save(request=request)
                messages.success(request, 'Email send')
                return redirect('login')
            except Exception as e:
                messages.error(request, f'failed: {e}')
    else:
        form = PasswordResetForm()
    return render(request, 'forget.html', {'form': form})


class CustomPasswordResetConfirmView(PasswordResetConfirmView):
    success_url = reverse_lazy('login')

    def form_valid(self, form):
        self.user = form.save()
        return redirect (self.get_success_url())
    
class CustomPasswordResetView(PasswordResetView):
    template_name = 'your_password_reset_form.html'
    success_url = reverse_lazy('login')


def search(request):
    query = request.GET.get('q')
    if query:
        results = Product.objects.filter(name__icontains=query)
        return render(request, 'search_results.html', {'results': results, 'query': query})
    else:
        return render(request, 'search_results.html', {'results': None, 'query': None})