from django.contrib import admin

from App.models import *

# Register your models here.
admin.site.register(Product)
admin.site.register(CartItem)
admin.site.register(Orders)
admin.site.register(Banner)
admin.site.register(OrderItem)
admin.site.register(ContactMessage)