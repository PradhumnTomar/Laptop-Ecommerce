from  django.urls import include, path
from App import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from .views import CustomPasswordResetConfirmView, CustomPasswordResetView

urlpatterns = [
    path('signup/',views.signup, name = 'signup'),
    path('',views.loginpage, name= 'login'),
    path('home/',views.home, name='home'),
    path('logoutbutton/',views.logoutbutton,name='logoutbutton'),
    path('add_product/',views.add_product, name='add_product'),
    path('product_list/',views.product_list, name='product_list'),
    path('your_cart/',views.your_cart,name='your_cart'),
    path('add_to_cart/',views.add_to_cart,name='add_to_cart'),
    path('social-auth/', include('social_django.urls', namespace='social')),
    path('decrease_quantity/', views.decrease_quantity, name='decrease_quantity'),
    path('increase_quantity/', views.increase_quantity, name='increase_quantity'),
    path('delete_item/', views.delete_item, name='delete_item'),
    path('delete_item_admin/', views.delete_item_admin, name='delete_item_admin'),
    path('popup/',views.popup, name='popup'),
    path('banner/',views.banner, name='banner'),
    path('delete_banner/', views.delete_banner, name='delete_banner'),
    path('footer/',views.footer, name='footer'),
    path('user_orders/', views.user_orders, name='user_orders'),
    path('user_order_admin_view/', views.user_order_admin_view, name='user_order_admin_view'),
    path('confirm_order/<int:order_id>/', views.confirm_order, name='confirm_order'),
    path('forgot_password/', views.forgot_password, name='forgot_password'),
    path('reset_password/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('reset_password/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    path('reset/<uidb64>/<token>/', CustomPasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset_password/', CustomPasswordResetView.as_view(), name='reset_password'),
    path('contact/', views.contact_us, name='contact_us'),
    path('messages_to_admin/', views.messages_to_admin, name='messages_to_admin'),
    path('search/', views.search, name='search'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)